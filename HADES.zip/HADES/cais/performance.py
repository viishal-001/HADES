"""
Real-time Performance Optimization Module
Provides caching, batching, and latency monitoring for CAIS
"""
import time
import hashlib
from functools import lru_cache
from typing import Dict, Any, Optional, Tuple
from collections import deque
from dataclasses import dataclass
from loguru import logger


@dataclass
class PerformanceMetrics:
    """Track performance metrics"""
    total_requests: int = 0
    total_latency_ms: float = 0.0
    avg_latency_ms: float = 0.0
    min_latency_ms: float = float('inf')
    max_latency_ms: float = 0.0
    cache_hits: int = 0
    cache_misses: int = 0
    
    def update(self, latency_ms: float, cache_hit: bool = False):
        """Update metrics with new request"""
        self.total_requests += 1
        self.total_latency_ms += latency_ms
        self.avg_latency_ms = self.total_latency_ms / self.total_requests
        self.min_latency_ms = min(self.min_latency_ms, latency_ms)
        self.max_latency_ms = max(self.max_latency_ms, latency_ms)
        
        if cache_hit:
            self.cache_hits += 1
        else:
            self.cache_misses += 1
    
    @property
    def cache_hit_rate(self) -> float:
        """Calculate cache hit rate"""
        total = self.cache_hits + self.cache_misses
        return (self.cache_hits / total * 100) if total > 0 else 0.0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'total_requests': self.total_requests,
            'avg_latency_ms': round(self.avg_latency_ms, 2),
            'min_latency_ms': round(self.min_latency_ms, 2),
            'max_latency_ms': round(self.max_latency_ms, 2),
            'cache_hit_rate': round(self.cache_hit_rate, 2)
        }


class ResultCache:
    """LRU cache for detection results"""
    
    def __init__(self, max_size: int = 1000, ttl_seconds: int = 300):
        self.max_size = max_size
        self.ttl_seconds = ttl_seconds
        self.cache: Dict[str, Tuple[Any, float]] = {}
        self.access_order = deque(maxlen=max_size)
    
    def _hash_input(self, text: str) -> str:
        """Create hash of input text"""
        return hashlib.sha256(text.encode('utf-8')).hexdigest()[:16]
    
    def get(self, text: str) -> Optional[Any]:
        """Get cached result if available and not expired"""
        key = self._hash_input(text)
        
        if key in self.cache:
            result, timestamp = self.cache[key]
            
            # Check if expired
            if time.time() - timestamp < self.ttl_seconds:
                # Move to end (most recently used)
                if key in self.access_order:
                    self.access_order.remove(key)
                self.access_order.append(key)
                return result
            else:
                # Expired, remove
                del self.cache[key]
        
        return None
    
    def set(self, text: str, result: Any):
        """Cache a result"""
        key = self._hash_input(text)
        
        # Evict oldest if at capacity
        if len(self.cache) >= self.max_size and key not in self.cache:
            if self.access_order:
                oldest_key = self.access_order.popleft()
                if oldest_key in self.cache:
                    del self.cache[oldest_key]
        
        self.cache[key] = (result, time.time())
        
        if key in self.access_order:
            self.access_order.remove(key)
        self.access_order.append(key)
    
    def clear(self):
        """Clear all cached results"""
        self.cache.clear()
        self.access_order.clear()
    
    @property
    def size(self) -> int:
        """Current cache size"""
        return len(self.cache)


class LatencyMonitor:
    """Monitor and track latency for different components"""
    
    def __init__(self, window_size: int = 100):
        self.window_size = window_size
        self.timings: Dict[str, deque] = {}
    
    def record(self, component: str, latency_ms: float):
        """Record latency for a component"""
        if component not in self.timings:
            self.timings[component] = deque(maxlen=self.window_size)
        
        self.timings[component].append(latency_ms)
    
    def get_stats(self, component: str) -> Dict[str, float]:
        """Get statistics for a component"""
        if component not in self.timings or not self.timings[component]:
            return {}
        
        timings = list(self.timings[component])
        return {
            'avg_ms': sum(timings) / len(timings),
            'min_ms': min(timings),
            'max_ms': max(timings),
            'p50_ms': sorted(timings)[len(timings) // 2],
            'p95_ms': sorted(timings)[int(len(timings) * 0.95)],
            'p99_ms': sorted(timings)[int(len(timings) * 0.99)]
        }
    
    def get_all_stats(self) -> Dict[str, Dict[str, float]]:
        """Get statistics for all components"""
        return {
            component: self.get_stats(component)
            for component in self.timings.keys()
        }


# Global instances
_metrics = PerformanceMetrics()
_cache = ResultCache(max_size=1000, ttl_seconds=300)
_latency_monitor = LatencyMonitor(window_size=100)


def get_metrics() -> PerformanceMetrics:
    """Get global metrics instance"""
    return _metrics


def get_cache() -> ResultCache:
    """Get global cache instance"""
    return _cache


def get_latency_monitor() -> LatencyMonitor:
    """Get global latency monitor instance"""
    return _latency_monitor


class PerformanceTimer:
    """Context manager for timing operations"""
    
    def __init__(self, component: str):
        self.component = component
        self.start_time = None
        self.latency_ms = None
    
    def __enter__(self):
        self.start_time = time.time()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.latency_ms = (time.time() - self.start_time) * 1000
        _latency_monitor.record(self.component, self.latency_ms)
        
        # Log if latency is high
        if self.latency_ms > 100:
            logger.warning(f"{self.component} took {self.latency_ms:.2f}ms (high latency)")
