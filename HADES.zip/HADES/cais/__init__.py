"""
CAIS - Context-Aware Intent Shield
A low-latency defense layer for LLM-powered security tools
"""

__version__ = "0.1.0"
__author__ = "CAIS Team"

from cais.core import CAISMiddleware
from cais.models import ProtectionResult, IntentClass, MitigationAction

__all__ = [
    "CAISMiddleware",
    "ProtectionResult",
    "IntentClass",
    "MitigationAction",
]
