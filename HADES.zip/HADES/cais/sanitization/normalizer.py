"""
Input sanitization and normalization engine
Handles Unicode normalization, decoding, and character filtering
"""
import re
import base64
import urllib.parse
import unicodedata
from typing import Tuple, List
from loguru import logger


class InputNormalizer:
    """Normalizes and sanitizes user input"""
    
    # Invisible and zero-width characters to remove
    INVISIBLE_CHARS = [
        '\u200b',  # Zero-width space
        '\u200c',  # Zero-width non-joiner
        '\u200d',  # Zero-width joiner
        '\u2060',  # Word joiner
        '\ufeff',  # Zero-width no-break space
        '\u180e',  # Mongolian vowel separator
        '\u034f',  # Combining grapheme joiner
    ]
    
    # Homoglyph mappings (common confusables)
    HOMOGLYPH_MAP = {
        'а': 'a', 'е': 'e', 'о': 'o', 'р': 'p', 'с': 'c', 'х': 'x',  # Cyrillic
        'ı': 'i', 'ş': 's', 'ğ': 'g',  # Turkish
        '０': '0', '１': '1', '２': '2', '３': '3', '４': '4',  # Fullwidth
        '５': '5', '６': '6', '７': '7', '８': '8', '９': '9',
    }
    
    def __init__(self, max_decode_depth: int = 2):
        self.max_decode_depth = max_decode_depth
        
    def normalize(self, text: str) -> Tuple[str, List[str]]:
        """
        Normalize input text through multiple stages
        
        Returns:
            Tuple of (normalized_text, transformations_applied)
        """
        transformations = []
        original = text
        
        # 1. Unicode normalization (NFKC)
        text = unicodedata.normalize('NFKC', text)
        if text != original:
            transformations.append("unicode_nfkc")
        
        # 2. Remove invisible characters
        text, removed = self._remove_invisible_chars(text)
        if removed:
            transformations.append("removed_invisible_chars")
        
        # 3. Normalize homoglyphs
        text, replaced = self._normalize_homoglyphs(text)
        if replaced:
            transformations.append("normalized_homoglyphs")
        
        # 4. Recursive decoding
        text, decoded = self._recursive_decode(text)
        if decoded:
            transformations.extend(decoded)
        
        # 5. Normalize whitespace
        text = self._normalize_whitespace(text)
        
        logger.debug(f"Normalization applied: {transformations}")
        return text, transformations
    
    def _remove_invisible_chars(self, text: str) -> Tuple[str, bool]:
        """Remove invisible and zero-width characters"""
        original = text
        for char in self.INVISIBLE_CHARS:
            text = text.replace(char, '')
        
        # Remove other control characters except newline, tab, carriage return
        text = ''.join(
            char for char in text
            if unicodedata.category(char)[0] != 'C' or char in '\n\t\r'
        )
        
        return text, text != original
    
    def _normalize_homoglyphs(self, text: str) -> Tuple[str, bool]:
        """Replace common homoglyphs with ASCII equivalents"""
        original = text
        for homoglyph, replacement in self.HOMOGLYPH_MAP.items():
            text = text.replace(homoglyph, replacement)
        return text, text != original
    
    def _recursive_decode(self, text: str) -> Tuple[str, List[str]]:
        """Recursively decode Base64, URL, and Hex encoded content"""
        decoded_layers = []
        current = text
        
        for depth in range(self.max_decode_depth):
            decoded = self._try_decode(current)
            if decoded != current:
                decoded_layers.append(f"decode_layer_{depth+1}")
                current = decoded
            else:
                break
        
        return current, decoded_layers
    
    def _try_decode(self, text: str) -> str:
        """Attempt to decode text using various encodings"""
        # Try Base64
        try:
            # Remove whitespace for Base64
            cleaned = re.sub(r'\s', '', text)
            if len(cleaned) > 0 and len(cleaned) % 4 == 0:
                decoded = base64.b64decode(cleaned, validate=True).decode('utf-8', errors='ignore')
                if decoded and self._is_meaningful(decoded):
                    logger.debug(f"Base64 decoded: {text[:50]}... -> {decoded[:50]}...")
                    return decoded
        except Exception:
            pass
        
        # Try URL encoding
        try:
            decoded = urllib.parse.unquote(text)
            if decoded != text and self._is_meaningful(decoded):
                logger.debug(f"URL decoded: {text[:50]}... -> {decoded[:50]}...")
                return decoded
        except Exception:
            pass
        
        # Try Hex decoding
        try:
            if re.match(r'^[0-9a-fA-F]+$', text.replace(' ', '')):
                hex_str = text.replace(' ', '')
                if len(hex_str) % 2 == 0:
                    decoded = bytes.fromhex(hex_str).decode('utf-8', errors='ignore')
                    if decoded and self._is_meaningful(decoded):
                        logger.debug(f"Hex decoded: {text[:50]}... -> {decoded[:50]}...")
                        return decoded
        except Exception:
            pass
        
        return text
    
    def _is_meaningful(self, text: str) -> bool:
        """Check if decoded text is meaningful (not garbage)"""
        if len(text) < 3:
            return False
        
        # Check if it contains reasonable ASCII characters
        printable_ratio = sum(1 for c in text if c.isprintable() or c in '\n\t\r') / len(text)
        return printable_ratio > 0.7
    
    def _normalize_whitespace(self, text: str) -> str:
        """Normalize whitespace while preserving structure"""
        # Replace multiple spaces with single space
        text = re.sub(r' +', ' ', text)
        # Replace multiple newlines with double newline
        text = re.sub(r'\n{3,}', '\n\n', text)
        return text.strip()


class InputCleaner:
    """Additional cleaning operations for security"""
    
    # Patterns that might break tokenization
    TOKENIZATION_BREAKERS = [
        r'<\|.*?\|>',  # Special tokens
        r'\[INST\].*?\[/INST\]',  # Instruction markers
        r'###\s*System:',  # System prompts
        r'###\s*Assistant:',  # Assistant markers
    ]
    
    def clean_for_analysis(self, text: str) -> str:
        """
        Clean text for safe analysis
        Does NOT remove content, only normalizes structure
        """
        # Remove potential tokenization breakers (for logging/analysis only)
        cleaned = text
        for pattern in self.TOKENIZATION_BREAKERS:
            cleaned = re.sub(pattern, '', cleaned, flags=re.IGNORECASE)
        
        return cleaned.strip()
    
    def extract_code_blocks(self, text: str) -> List[Tuple[str, str]]:
        """Extract code blocks from markdown-style text"""
        pattern = r'```(\w+)?\n(.*?)```'
        matches = re.findall(pattern, text, re.DOTALL)
        return [(lang or 'unknown', code.strip()) for lang, code in matches]
    
    def extract_urls(self, text: str) -> List[str]:
        """Extract URLs from text"""
        url_pattern = r'https?://[^\s<>"{}|\\^`\[\]]+'
        return re.findall(url_pattern, text)
