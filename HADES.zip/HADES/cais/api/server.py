"""
FastAPI server for CAIS middleware
Provides REST API for protection services
"""
import time
from typing import Optional, Dict, Any, List
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from loguru import logger

from cais.core import CAISMiddleware
from cais.models import Config, MitigationAction
from cais.performance import get_metrics, get_cache, get_latency_monitor


# Request/Response models
class ProtectRequest(BaseModel):
    """Request to protect input"""
    session_id: str = Field(default="default", description="Session identifier")
    input: str = Field(..., description="User input to protect")
    messages: Optional[List[Dict[str, str]]] = Field(None, description="Conversation history for multi-turn analysis")
    context: Optional[str] = Field(None, description="Context hint (e.g., 'code_review')")


class ProtectResponse(BaseModel):
    """Protection result"""
    action: str
    sanitized_input: str
    intent: Optional[str]
    confidence: float
    reason: Optional[str]
    session_risk: Optional[Dict[str, Any]]
    metadata: Dict[str, Any]
    processing_time_ms: float


class ValidateResponseRequest(BaseModel):
    """Request to validate LLM response"""
    response: str = Field(..., description="LLM response to validate")


class ValidateResponseResponse(BaseModel):
    """Validation result"""
    is_safe: bool
    reason: str
    sanitized_response: Optional[str] = None


class SessionInfoResponse(BaseModel):
    """Session information"""
    session_id: str
    risk_score: float
    turn_count: int
    suspicious_turns: int
    locked: bool
    lock_reason: Optional[str]


class HealthResponse(BaseModel):
    """Health check response"""
    status: str
    version: str
    uptime_seconds: float


# Global middleware instance
cais_middleware: Optional[CAISMiddleware] = None
start_time: float = 0


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifespan context manager"""
    global cais_middleware, start_time
    
    # Startup
    logger.info("Starting CAIS API server...")
    start_time = time.time()
    
    try:
        config = Config()
        cais_middleware = CAISMiddleware(config)
        logger.info("CAIS middleware initialized")
    except Exception as e:
        logger.error(f"Failed to initialize CAIS middleware: {e}")
        raise
    
    yield
    
    # Shutdown
    logger.info("Shutting down CAIS API server...")


# Create FastAPI app
app = FastAPI(
    title="CAIS - Context-Aware Intent Shield",
    description="Low-latency defense layer for LLM-powered security tools",
    version="0.1.0",
    lifespan=lifespan
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure appropriately for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Middleware for request logging
@app.middleware("http")
async def log_requests(request: Request, call_next):
    """Log all requests"""
    start = time.time()
    
    response = await call_next(request)
    
    duration = (time.time() - start) * 1000
    logger.info(
        f"{request.method} {request.url.path} - "
        f"Status: {response.status_code} - "
        f"Duration: {duration:.2f}ms"
    )
    
    return response


# API Endpoints

@app.get("/", response_model=Dict[str, str])
async def root():
    """Root endpoint"""
    return {
        "service": "CAIS - Context-Aware Intent Shield",
        "version": "0.1.0",
        "status": "operational",
        "docs": "/docs"
    }


@app.get("/health", response_model=HealthResponse)
async def health():
    """Health check endpoint"""
    uptime = time.time() - start_time
    
    return HealthResponse(
        status="healthy" if cais_middleware else "unhealthy",
        version="0.1.0",
        uptime_seconds=uptime
    )


@app.get("/metrics", response_model=Dict[str, Any])
async def metrics():
    """
    Get real-time performance metrics
    
    Returns latency statistics, cache performance, and component timings
    """
    perf_metrics = get_metrics()
    cache = get_cache()
    latency_monitor = get_latency_monitor()
    
    return {
        "performance": perf_metrics.to_dict(),
        "cache": {
            "size": cache.size,
            "max_size": cache.max_size,
            "ttl_seconds": cache.ttl_seconds
        },
        "component_latency": latency_monitor.get_all_stats()
    }


@app.post("/protect", response_model=ProtectResponse)
async def protect(request: ProtectRequest):
    """
    Protect user input from prompt injection
    
    This is the main endpoint for CAIS protection.
    """
    if not cais_middleware:
        raise HTTPException(status_code=503, detail="CAIS middleware not initialized")
    
    try:
        # Run protection
        result = cais_middleware.protect(
            input_text=request.input,
            session_id=request.session_id,
            context=request.context,
            messages=request.messages
        )
        
        # Convert to response
        return ProtectResponse(
            action=result.action.value,
            sanitized_input=result.sanitized_input,
            intent=result.intent.value if result.intent else None,
            confidence=result.confidence,
            reason=result.reason,
            session_risk=result.session_risk.dict() if result.session_risk else None,
            metadata=result.metadata,
            processing_time_ms=result.processing_time_ms
        )
        
    except Exception as e:
        logger.error(f"Protection failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Protection failed: {str(e)}")


@app.post("/validate-response", response_model=ValidateResponseResponse)
async def validate_response(request: ValidateResponseRequest):
    """
    Validate LLM response for potential prompt leakage
    """
    if not cais_middleware:
        raise HTTPException(status_code=503, detail="CAIS middleware not initialized")
    
    try:
        is_safe, reason = cais_middleware.validate_response(request.response)
        
        sanitized = None
        if not is_safe:
            sanitized = cais_middleware.sanitize_response(request.response)
        
        return ValidateResponseResponse(
            is_safe=is_safe,
            reason=reason,
            sanitized_response=sanitized
        )
        
    except Exception as e:
        logger.error(f"Response validation failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Validation failed: {str(e)}")


@app.get("/session/{session_id}", response_model=SessionInfoResponse)
async def get_session(session_id: str):
    """Get session information"""
    if not cais_middleware:
        raise HTTPException(status_code=503, detail="CAIS middleware not initialized")
    
    try:
        info = cais_middleware.get_session_info(session_id)
        
        if not info:
            raise HTTPException(status_code=404, detail="Session not found")
        
        return SessionInfoResponse(**info)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get session info: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Failed to get session: {str(e)}")


@app.post("/session/{session_id}/reset")
async def reset_session(session_id: str):
    """Reset a session"""
    if not cais_middleware:
        raise HTTPException(status_code=503, detail="CAIS middleware not initialized")
    
    try:
        cais_middleware.reset_session(session_id)
        return {"status": "success", "message": f"Session {session_id} reset"}
        
    except Exception as e:
        logger.error(f"Failed to reset session: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Failed to reset session: {str(e)}")


@app.get("/stats")
async def get_stats():
    """Get service statistics"""
    if not cais_middleware:
        raise HTTPException(status_code=503, detail="CAIS middleware not initialized")
    
    uptime = time.time() - start_time
    
    return {
        "uptime_seconds": uptime,
        "version": "0.1.0",
        "status": "operational"
    }


# Error handlers
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """Global exception handler"""
    logger.error(f"Unhandled exception: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={
            "detail": "Internal server error",
            "error": str(exc)
        }
    )


if __name__ == "__main__":
    import uvicorn
    
    # Configure logging
    logger.add(
        "logs/cais_{time}.log",
        rotation="100 MB",
        retention="7 days",
        level="INFO"
    )
    
    # Run server
    uvicorn.run(
        "cais.api.server:app",
        host="0.0.0.0",
        port=8000,
        reload=False,
        log_level="info"
    )
