"""
Data models for CAIS
"""
from enum import Enum
from typing import Optional, Dict, Any, List
from pydantic import BaseModel, Field


class IntentClass(str, Enum):
    """Intent classification categories"""
    LEGITIMATE_QUERY = "legitimate_query"
    LEGITIMATE_CODE_ANALYSIS = "legitimate_code_analysis"
    DIRECT_ATTACK = "direct_attack"
    INDIRECT_ATTACK = "indirect_attack"


class MitigationAction(str, Enum):
    """Mitigation actions"""
    ALLOW = "allow"
    SANITIZE = "sanitize"
    BLOCK = "block"
    REPROMPT = "reprompt"
    CONTAIN = "contain"


class RiskLevel(str, Enum):
    """Risk levels for session tracking"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class ProtectionRequest(BaseModel):
    """Request to protect an input"""
    session_id: str = Field(..., description="Unique session identifier")
    input: str = Field(..., description="User input to protect")
    messages: Optional[List[Dict[str, str]]] = Field(None, description="Conversation history for multi-turn analysis")
    context: Optional[str] = Field(None, description="Context hint (e.g., 'code_review', 'soc_analysis')")
    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Additional metadata")


class DetectionResult(BaseModel):
    """Result from detection layer"""
    is_suspicious: bool
    confidence: float = Field(ge=0.0, le=1.0)
    matched_patterns: List[str] = Field(default_factory=list)
    detection_method: str  # "regex", "vector", "heuristic"


class ClassificationResult(BaseModel):
    """Result from intent classification"""
    intent: IntentClass
    confidence: float = Field(ge=0.0, le=1.0)
    scores: Dict[str, float] = Field(default_factory=dict)
    reasoning: Optional[str] = None
    features: Optional[Dict[str, Any]] = None


class SessionRisk(BaseModel):
    """Session risk assessment"""
    session_id: str
    risk_score: float = Field(ge=0.0, le=100.0)
    risk_level: RiskLevel
    turn_count: int
    suspicious_turns: int
    last_intent: Optional[IntentClass] = None


class ProtectionResult(BaseModel):
    """Final protection result"""
    action: MitigationAction
    sanitized_input: str
    original_input: str
    intent: Optional[IntentClass] = None
    confidence: float = Field(ge=0.0, le=1.0)
    session_risk: Optional[SessionRisk] = None
    reason: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)
    processing_time_ms: float


class Config(BaseModel):
    """CAIS configuration"""
    # Detection thresholds
    regex_detection_enabled: bool = True
    vector_detection_enabled: bool = True
    vector_similarity_threshold: float = 0.85
    
    # Classification
    classification_model_path: str = "models/intent_classifier"
    use_onnx: bool = True
    confidence_threshold: float = 0.7
    
    # Session tracking
    session_tracking_enabled: bool = True
    session_risk_threshold: float = 70.0
    max_session_turns: int = 100
    
    # Mitigation
    auto_block_direct_attacks: bool = True
    sanitize_indirect_attacks: bool = True
    use_xml_spotlighting: bool = True
    
    # Performance
    max_input_length: int = 8192
    max_decode_depth: int = 2
    enable_caching: bool = True
    
    # Logging
    log_level: str = "INFO"
    log_blocked_attempts: bool = True
