"""
Core CAIS middleware
Orchestrates all protection layers
"""
import time
from typing import Optional, List, Dict
from loguru import logger

from cais.models import (
    Config, ProtectionRequest, ProtectionResult,
    MitigationAction, IntentClass, DetectionResult
)
from cais.sanitization import InputNormalizer, InputCleaner
from cais.detection import HeuristicDetector, ContextAnalyzer, VectorDetector, HybridDetector
from cais.detection.obfuscation import ObfuscationDetector
from cais.classification import IntentClassifier
from cais.session import SessionTracker
from cais.mitigation import MitigationEngine, ResponseValidator
from cais.performance import (
    get_metrics, get_cache, get_latency_monitor,
    PerformanceTimer
)


class CAISMiddleware:
    """
    Main CAIS protection middleware
    Coordinates all defense layers
    """
    
    def __init__(self, config: Optional[Config] = None):
        self.config = config or Config()
        
        # Initialize components
        logger.info("Initializing CAIS middleware...")
        
        # Sanitization
        self.normalizer = InputNormalizer(
            max_decode_depth=self.config.max_decode_depth
        )
        self.cleaner = InputCleaner()
        
        # Detection
        self.heuristic_detector = HeuristicDetector()
        self.context_analyzer = ContextAnalyzer()
        self.obfuscation_detector = ObfuscationDetector()
        
        vector_detector = None
        if self.config.vector_detection_enabled:
            try:
                vector_detector = VectorDetector(
                    similarity_threshold=self.config.vector_similarity_threshold
                )
            except Exception as e:
                logger.warning(f"Vector detector initialization failed: {e}")
        
        self.detector = HybridDetector(
            heuristic_detector=self.heuristic_detector,
            vector_detector=vector_detector
        )
        
        # Classification
        self.classifier = IntentClassifier(
            model_path=self.config.classification_model_path,
            use_onnx=self.config.use_onnx,
            confidence_threshold=self.config.confidence_threshold
        )
        
        # Session tracking
        self.session_tracker = None
        if self.config.session_tracking_enabled:
            self.session_tracker = SessionTracker(
                max_turns=self.config.max_session_turns,
                risk_threshold=self.config.session_risk_threshold
            )
        
        # Mitigation
        self.mitigation_engine = MitigationEngine(
            auto_block_direct_attacks=self.config.auto_block_direct_attacks,
            sanitize_indirect_attacks=self.config.sanitize_indirect_attacks,
            use_xml_spotlighting=self.config.use_xml_spotlighting
        )
        
        self.response_validator = ResponseValidator()
        
        logger.info("CAIS middleware initialized successfully")
    
    def protect(
        self,
        input_text: str,
        session_id: str = "default",
        context: Optional[str] = None,
        messages: Optional[List[Dict[str, str]]] = None
    ) -> ProtectionResult:
        """
        Main protection pipeline
        
        Args:
            input_text: User input to protect
            session_id: Session identifier for tracking
            context: Optional context hint (e.g., 'code_review')
        
        Returns:
            ProtectionResult with action and sanitized input
        """
        start_time = time.time()
        cache = get_cache()
        metrics = get_metrics()
        
        try:
            # Check cache first for identical inputs
            cached_result = cache.get(input_text)
            if cached_result is not None:
                latency_ms = (time.time() - start_time) * 1000
                metrics.update(latency_ms, cache_hit=True)
                logger.debug(f"Cache hit! Latency: {latency_ms:.2f}ms")
                return cached_result
            
            # 1. Input validation
            with PerformanceTimer("input_validation"):
                if not input_text or len(input_text) > self.config.max_input_length:
                    return self._create_blocked_result(
                        input_text,
                        "Input validation failed",
                        start_time
                    )
                
                # EMERGENCY DLP CHECK - Fail Safe
                import re
                dlp_patterns = [
                    (r'AKIA[0-9A-Z]{16}', 'AWS Key Leak'),
                    (r'(aws|access|secret).*?(key|token).*?[a-zA-Z0-9/+=]{20,}', 'Secret Key Leak'),
                    (r'\b\d{3}-\d{2}-\d{4}\b', 'SSN Leak'),
                    (r'email[:=]\s*[\w\.-]+@[\w\.-]+\.\w+', 'Email Leak')
                ]
                for pattern, label in dlp_patterns:
                    if re.search(pattern, input_text, re.IGNORECASE):
                        logger.warning(f"DLP Fail-safe trigger: {label}")
                        # Check cache (and update it to block future requests)
                        result = self._create_blocked_result(input_text, f"Sensitive Data Detected (DLP: {label})", start_time)
                        # Ensure we cache this block
                        get_cache().set(input_text, result)
                        return result
            
            # 2. Sanitization & Normalization
            # Prepare text for detection (possibly including history)
            detection_text = input_text
            if messages:
                # Concatenate last 5 user/assistant messages for context
                # Format: "role: content\n"
                history_text = ""
                for msg in messages[-5:]:
                    role = msg.get("role", "user")
                    content = msg.get("content", "")
                    if content:
                        history_text += f"{role}: {content}\n"
                
                detection_text = f"{history_text}user: {input_text}"
                logger.debug(f"Using multi-turn context for detection (length: {len(detection_text)})")

            # Run obfuscation detection first
            deobfuscated_text, obfuscation_techniques, obfuscation_score = \
                self.obfuscation_detector.detect_and_normalize(input_text)
            
            if obfuscation_techniques:
                logger.warning(f"Obfuscation detected: {obfuscation_techniques} (score: {obfuscation_score:.2f})")
                # Use deobfuscated text for further processing
                normalized_text = deobfuscated_text
                transformations = [f"obfuscation_{t}" for t in obfuscation_techniques]
            else:
                # Standard normalization
                normalized_text, transformations = self.normalizer.normalize(input_text)
            
            # Also normalize detection text (with history)
            normalized_detection_text, _ = self.normalizer.normalize(detection_text)
            
            logger.debug(f"Normalization transformations: {transformations}")
            
            # 3. Fast-Path Detection
            # If obfuscation was detected, re-run detection on deobfuscated text
            if obfuscation_techniques:
                # Use deobfuscated text for detection
                is_suspicious, detection_conf, matched_patterns, detection_method = \
                    self.detector.detect(normalized_text)
                
                # If high obfuscation score, treat as suspicious even if patterns don't match
                if obfuscation_score >= 0.5 and not is_suspicious:
                    is_suspicious = True
                    detection_conf = obfuscation_score
                    matched_patterns = [f"obfuscation_{t}" for t in obfuscation_techniques]
                    detection_method = "obfuscation_detection"
                    logger.warning(f"Flagged as suspicious due to high obfuscation score: {obfuscation_score:.2f}")
                
                # Boost confidence if obfuscation was used to hide attack
                if is_suspicious:
                    detection_conf = min(0.95, detection_conf + obfuscation_score * 0.2)
                    logger.warning(f"Obfuscated attack detected! Boosted confidence to {detection_conf:.2f}")
            else:
                # Standard detection on normalized text
                is_suspicious, detection_conf, matched_patterns, detection_method = \
                    self.detector.detect(normalized_detection_text)
            
            # Check for split payloads by identifying user stream
            if messages:
                user_stream = ""
                for msg in messages[-5:]:
                    if msg.get("role") == "user":
                        content = msg.get("content", "")
                        if content:
                            user_stream += content + " "
                user_stream += input_text
                
                normalized_stream, _ = self.normalizer.normalize(user_stream)
                
                stream_suspicious, stream_conf, stream_patterns, stream_method = \
                    self.detector.detect(normalized_stream)
                
                # Fallback to raw stream detection if normalized failed (avoids normalization artifacts)
                if not stream_suspicious:
                    raw_suspicious, raw_conf, raw_patterns, raw_method = self.detector.detect(user_stream)
                    if raw_suspicious:
                        stream_suspicious = True
                        stream_conf = raw_conf
                        stream_patterns = raw_patterns
                        stream_method = raw_method + " (raw)"
                
                if stream_suspicious:
                    logger.warning(
                        f"Suspicious split payload detected via {stream_method}: "
                        f"patterns={stream_patterns}, confidence={stream_conf:.2f}"
                    )
                    is_suspicious = True
                    detection_conf = max(detection_conf, stream_conf)
                    matched_patterns.extend(stream_patterns)
                    matched_patterns = list(set(matched_patterns))
                    detection_method = f"{detection_method} (split)"
            
            if is_suspicious:
                logger.warning(
                    f"Suspicious input detected via {detection_method}: "
                    f"patterns={matched_patterns}, confidence={detection_conf:.2f}"
                )
            
            # 4. Context Analysis
            is_analysis, analysis_conf = self.context_analyzer.is_likely_analysis(normalized_text)
            
            if is_analysis:
                logger.info(f"Detected legitimate analysis intent (confidence: {analysis_conf:.2f})")
            
            # 5. Intent Classification
            # Use normalized_detection_text for context-aware classification
            classification_result = self.classifier.classify(normalized_detection_text)
            intent = classification_result.intent
            intent_confidence = classification_result.confidence
            
            # Override intent if suspicious patterns were detected
            if is_suspicious and intent not in [IntentClass.DIRECT_ATTACK, IntentClass.INDIRECT_ATTACK, IntentClass.LEGITIMATE_CODE_ANALYSIS]:
                logger.warning(f"Overriding classified intent {intent.value} due to detected patterns: {matched_patterns}")
                
                # Distinguish between Direct Overrides and Indirect/Data Injections
                if any(p in ['xss_payload', 'code_comment_injection'] for p in matched_patterns):
                    intent = IntentClass.INDIRECT_ATTACK
                    # Confidence is high that it's an injection
                    intent_confidence = 0.95
                else:
                    intent = IntentClass.DIRECT_ATTACK
                    intent_confidence = detection_conf
            
            logger.info(
                f"Intent classified as {intent.value} "
                f"(confidence: {intent_confidence:.2f})"
            )
            
            # 6. Session Risk Evaluation
            session_risk = None
            is_session_locked = False
            
            if self.session_tracker:
                session_risk = self.session_tracker.update(
                    session_id=session_id,
                    intent=intent,
                    confidence=intent_confidence,
                    is_suspicious=is_suspicious
                )
                is_session_locked = self.session_tracker.is_session_locked(session_id)
                
                logger.info(
                    f"Session {session_id}: risk={session_risk.risk_score:.1f}, "
                    f"level={session_risk.risk_level.value}, locked={is_session_locked}"
                )
            
            # 7. Determine Mitigation Action
            action, reason = self.mitigation_engine.determine_action(
                intent=intent,
                confidence=intent_confidence,
                risk_level=session_risk.risk_level if session_risk else "low",
                is_session_locked=is_session_locked
            )
            
            # Use specific classification reasoning if available AND intent matches
            if intent == classification_result.intent and hasattr(classification_result, 'reasoning') and classification_result.reasoning:
                reason = classification_result.reasoning
            
            logger.info(f"Mitigation action: {action.value} - {reason[:100]}...")
            
            # 8. Apply Mitigation
            sanitized_input = self.mitigation_engine.apply_mitigation(
                text=normalized_text,
                action=action,
                intent=intent
            )
            
            # 9. Create Result
            processing_time = (time.time() - start_time) * 1000  # ms
            
            result = ProtectionResult(
                action=action,
                sanitized_input=sanitized_input,
                original_input=input_text,
                intent=intent,
                confidence=intent_confidence,
                session_risk=session_risk,
                reason=reason,
                metadata={
                    'transformations': transformations,
                    'detection_method': detection_method,
                    'matched_patterns': matched_patterns,
                    'detection_confidence': detection_conf,
                    'is_analysis': is_analysis,
                    'classification_scores': classification_result.scores,
                    'features': getattr(classification_result, 'features', None),
                    'obfuscation_techniques': obfuscation_techniques,
                },
                processing_time_ms=processing_time
            )
            
            logger.info(
                f"Protection completed in {processing_time:.2f}ms: "
                f"action={action.value}, intent={intent.value}"
            )
            
            # Cache the result for future identical requests
            cache.set(input_text, result)
            
            # Update performance metrics
            metrics.update(processing_time, cache_hit=False)
            
            return result
            
        except Exception as e:
            logger.error(f"Protection pipeline failed: {e}", exc_info=True)
            return self._create_error_result(input_text, str(e), start_time)
    
    def validate_response(self, response: str) -> tuple[bool, str]:
        """
        Validate LLM response for potential leakage
        
        Returns:
            (is_safe, reason)
        """
        return self.response_validator.check_response(response)
    
    def sanitize_response(self, response: str) -> str:
        """Sanitize LLM response"""
        return self.response_validator.sanitize_response(response)
    
    def reset_session(self, session_id: str):
        """Reset a session"""
        if self.session_tracker:
            self.session_tracker.reset_session(session_id)
    
    def get_session_info(self, session_id: str) -> dict:
        """Get session information"""
        if self.session_tracker:
            return self.session_tracker.get_session_info(session_id)
        return {}
    
    def _create_blocked_result(
        self,
        original_input: str,
        reason: str,
        start_time: float
    ) -> ProtectionResult:
        """Create a blocked result"""
        return ProtectionResult(
            action=MitigationAction.BLOCK,
            sanitized_input="",
            original_input=original_input,
            intent=IntentClass.DIRECT_ATTACK,
            confidence=1.0,
            session_risk=None,
            reason=reason,
            metadata={},
            processing_time_ms=(time.time() - start_time) * 1000
        )
    
    def _create_error_result(
        self,
        original_input: str,
        error: str,
        start_time: float
    ) -> ProtectionResult:
        """Create an error result"""
        return ProtectionResult(
            action=MitigationAction.BLOCK,
            sanitized_input="",
            original_input=original_input,
            intent=None,
            confidence=0.0,
            session_risk=None,
            reason=f"Processing error: {error}",
            metadata={'error': error},
            processing_time_ms=(time.time() - start_time) * 1000
        )
