"""
Session tracking and risk scoring
Detects multi-turn attack patterns and persona manipulation
"""
import time
from typing import Dict, Optional
from collections import defaultdict, deque
from loguru import logger

from cais.models import IntentClass, RiskLevel, SessionRisk


class SessionTracker:
    """Tracks session state and risk accumulation"""
    
    # Risk scores per intent
    INTENT_RISK_SCORES = {
        IntentClass.LEGITIMATE_QUERY: 0,
        IntentClass.LEGITIMATE_CODE_ANALYSIS: 5,  # Slightly elevated for security content
        IntentClass.DIRECT_ATTACK: 50,
        IntentClass.INDIRECT_ATTACK: 30,
    }
    
    # Risk decay per turn (for legitimate queries)
    RISK_DECAY_RATE = 2.0
    
    def __init__(
        self,
        max_turns: int = 100,
        risk_threshold: float = 70.0,
        window_size: int = 10
    ):
        self.max_turns = max_turns
        self.risk_threshold = risk_threshold
        self.window_size = window_size
        
        # Session storage
        self.sessions: Dict[str, Dict] = defaultdict(self._create_session)
        
        # Cleanup old sessions periodically
        self._last_cleanup = time.time()
        self._cleanup_interval = 3600  # 1 hour
    
    def _create_session(self) -> Dict:
        """Create new session state"""
        return {
            'risk_score': 0.0,
            'turn_count': 0,
            'suspicious_turns': 0,
            'intent_history': deque(maxlen=self.window_size),
            'created_at': time.time(),
            'last_activity': time.time(),
            'locked': False,
            'lock_reason': None,
        }
    
    def update(
        self,
        session_id: str,
        intent: IntentClass,
        confidence: float,
        is_suspicious: bool
    ) -> SessionRisk:
        """
        Update session state with new turn
        
        Returns:
            SessionRisk assessment
        """
        # Periodic cleanup
        self._maybe_cleanup()
        
        session = self.sessions[session_id]
        
        # Check if session is locked
        if session['locked']:
            logger.warning(f"Session {session_id} is locked: {session['lock_reason']}")
            return self._get_session_risk(session_id)
        
        # Update turn count
        session['turn_count'] += 1
        session['last_activity'] = time.time()
        
        # Add to history
        session['intent_history'].append({
            'intent': intent,
            'confidence': confidence,
            'is_suspicious': is_suspicious,
            'timestamp': time.time()
        })
        
        # Update suspicious turn count
        if is_suspicious:
            session['suspicious_turns'] += 1
        
        # Calculate risk score change
        base_risk = self.INTENT_RISK_SCORES.get(intent, 0)
        risk_change = base_risk * confidence
        
        # Apply risk change
        if is_suspicious or intent in [IntentClass.DIRECT_ATTACK, IntentClass.INDIRECT_ATTACK]:
            session['risk_score'] += risk_change
        else:
            # Decay risk for legitimate queries
            session['risk_score'] = max(0, session['risk_score'] - self.RISK_DECAY_RATE)
        
        # Cap risk score
        session['risk_score'] = min(100.0, session['risk_score'])
        
        # Check for attack patterns
        self._detect_attack_patterns(session_id)
        
        # Check if session should be locked
        if session['risk_score'] >= self.risk_threshold:
            self._lock_session(session_id, "Risk threshold exceeded")
        
        return self._get_session_risk(session_id)
    
    def _detect_attack_patterns(self, session_id: str):
        """Detect multi-turn attack patterns"""
        session = self.sessions[session_id]
        history = list(session['intent_history'])
        
        if len(history) < 3:
            return
        
        # Pattern 1: Repeated direct attacks
        recent_attacks = sum(
            1 for h in history[-5:]
            if h['intent'] == IntentClass.DIRECT_ATTACK
        )
        if recent_attacks >= 3:
            self._lock_session(session_id, "Repeated direct attack attempts")
            return
        
        # Pattern 2: Gradual escalation (probing)
        # Legitimate -> Indirect -> Direct
        if len(history) >= 3:
            last_three = [h['intent'] for h in history[-3:]]
            if (last_three[0] in [IntentClass.LEGITIMATE_QUERY, IntentClass.LEGITIMATE_CODE_ANALYSIS] and
                last_three[1] == IntentClass.INDIRECT_ATTACK and
                last_three[2] == IntentClass.DIRECT_ATTACK):
                session['risk_score'] += 20
                logger.warning(f"Session {session_id}: Escalation pattern detected")
        
        # Pattern 3: High frequency of suspicious turns
        if len(history) >= 10:
            suspicious_ratio = sum(1 for h in history[-10:] if h['is_suspicious']) / 10
            if suspicious_ratio > 0.5:
                session['risk_score'] += 15
                logger.warning(f"Session {session_id}: High suspicious turn ratio: {suspicious_ratio}")
    
    def _lock_session(self, session_id: str, reason: str):
        """Lock a session due to suspicious behavior"""
        session = self.sessions[session_id]
        session['locked'] = True
        session['lock_reason'] = reason
        logger.warning(f"Session {session_id} locked: {reason}")
    
    def unlock_session(self, session_id: str):
        """Manually unlock a session"""
        if session_id in self.sessions:
            self.sessions[session_id]['locked'] = False
            self.sessions[session_id]['lock_reason'] = None
            logger.info(f"Session {session_id} unlocked")
    
    def reset_session(self, session_id: str):
        """Reset a session"""
        if session_id in self.sessions:
            del self.sessions[session_id]
            logger.info(f"Session {session_id} reset")
    
    def _get_session_risk(self, session_id: str) -> SessionRisk:
        """Get current session risk assessment"""
        session = self.sessions[session_id]
        
        risk_score = session['risk_score']
        
        # Determine risk level
        if risk_score < 20:
            risk_level = RiskLevel.LOW
        elif risk_score < 50:
            risk_level = RiskLevel.MEDIUM
        elif risk_score < 80:
            risk_level = RiskLevel.HIGH
        else:
            risk_level = RiskLevel.CRITICAL
        
        # Get last intent
        last_intent = None
        if session['intent_history']:
            last_intent = session['intent_history'][-1]['intent']
        
        return SessionRisk(
            session_id=session_id,
            risk_score=risk_score,
            risk_level=risk_level,
            turn_count=session['turn_count'],
            suspicious_turns=session['suspicious_turns'],
            last_intent=last_intent
        )
    
    def is_session_locked(self, session_id: str) -> bool:
        """Check if session is locked"""
        return self.sessions[session_id]['locked']
    
    def get_session_info(self, session_id: str) -> Dict:
        """Get full session information"""
        session = self.sessions[session_id]
        return {
            'session_id': session_id,
            'risk_score': session['risk_score'],
            'turn_count': session['turn_count'],
            'suspicious_turns': session['suspicious_turns'],
            'locked': session['locked'],
            'lock_reason': session['lock_reason'],
            'created_at': session['created_at'],
            'last_activity': session['last_activity'],
            'history_length': len(session['intent_history']),
        }
    
    def _maybe_cleanup(self):
        """Cleanup old sessions periodically"""
        now = time.time()
        if now - self._last_cleanup < self._cleanup_interval:
            return
        
        # Remove sessions inactive for > 24 hours
        cutoff = now - 86400
        to_remove = [
            sid for sid, sess in self.sessions.items()
            if sess['last_activity'] < cutoff
        ]
        
        for sid in to_remove:
            del self.sessions[sid]
        
        if to_remove:
            logger.info(f"Cleaned up {len(to_remove)} inactive sessions")
        
        self._last_cleanup = now
