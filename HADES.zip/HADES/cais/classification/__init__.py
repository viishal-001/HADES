"""Classification module"""
from cais.classification.classifier import IntentClassifier

__all__ = ["IntentClassifier"]
