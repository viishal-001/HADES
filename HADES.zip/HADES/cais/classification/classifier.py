"""
Intent classification using fine-tuned transformer models
Classifies input into: Legitimate_Query, Legitimate_Code_Analysis, Direct_Attack, Indirect_Attack
"""
import os
import numpy as np
from typing import Dict, Optional, Tuple
from loguru import logger

from cais.models import IntentClass, ClassificationResult

try:
    from transformers import AutoTokenizer, AutoModelForSequenceClassification
    import torch
    TRANSFORMERS_AVAILABLE = True
except ImportError:
    TRANSFORMERS_AVAILABLE = False
    logger.warning("transformers not available. Using fallback classifier.")

try:
    import onnxruntime as ort
    ONNX_AVAILABLE = True
except ImportError:
    ONNX_AVAILABLE = False
    logger.warning("onnxruntime not available. ONNX inference disabled.")


class IntentClassifier:
    """Intent classification using transformer models"""
    
    # Label mapping
    LABEL_MAP = {
        0: IntentClass.LEGITIMATE_QUERY,
        1: IntentClass.LEGITIMATE_CODE_ANALYSIS,
        2: IntentClass.DIRECT_ATTACK,
        3: IntentClass.INDIRECT_ATTACK,
    }
    
    def __init__(
        self,
        model_path: Optional[str] = None,
        use_onnx: bool = True,
        confidence_threshold: float = 0.7
    ):
        self.model_path = model_path
        self.use_onnx = use_onnx and ONNX_AVAILABLE
        self.confidence_threshold = confidence_threshold
        
        self.tokenizer = None
        self.model = None
        self.ort_session = None
        
        # Try to load model
        if model_path and os.path.exists(model_path):
            self._load_model(model_path)
        else:
            logger.warning(f"Model not found at {model_path}. Using fallback classifier.")
            self._use_fallback = True
    
    def _load_model(self, model_path: str):
        """Load transformer model"""
        try:
            if self.use_onnx:
                onnx_path = os.path.join(model_path, "model.onnx")
                if os.path.exists(onnx_path):
                    logger.info(f"Loading ONNX model from {onnx_path}")
                    self.ort_session = ort.InferenceSession(onnx_path)
                    self.tokenizer = AutoTokenizer.from_pretrained(model_path)
                    self._use_fallback = False
                    logger.info("ONNX model loaded successfully")
                    return
            
            # Fall back to PyTorch
            if TRANSFORMERS_AVAILABLE:
                logger.info(f"Loading PyTorch model from {model_path}")
                self.tokenizer = AutoTokenizer.from_pretrained(model_path)
                self.model = AutoModelForSequenceClassification.from_pretrained(model_path)
                self.model.eval()
                self._use_fallback = False
                logger.info("PyTorch model loaded successfully")
            else:
                self._use_fallback = True
                
        except Exception as e:
            logger.error(f"Failed to load model: {e}")
            self._use_fallback = True
    
    def classify(self, text: str) -> ClassificationResult:
        """
        Classify input text into intent category
        
        Returns:
            ClassificationResult with intent, confidence, and scores
        """
        if self._use_fallback:
            return self._fallback_classify(text)
        
        try:
            if self.ort_session:
                return self._classify_onnx(text)
            elif self.model:
                return self._classify_pytorch(text)
            else:
                return self._fallback_classify(text)
        except Exception as e:
            logger.error(f"Classification failed: {e}")
            return self._fallback_classify(text)
    
    def _classify_onnx(self, text: str) -> ClassificationResult:
        """Classify using ONNX runtime"""
        # Tokenize
        inputs = self.tokenizer(
            text,
            padding=True,
            truncation=True,
            max_length=512,
            return_tensors="np"
        )
        
        # Run inference
        ort_inputs = {
            "input_ids": inputs["input_ids"].astype(np.int64),
            "attention_mask": inputs["attention_mask"].astype(np.int64),
        }
        
        logits = self.ort_session.run(None, ort_inputs)[0]
        
        # Softmax
        scores = self._softmax(logits[0])
        
        # Get prediction
        pred_idx = int(np.argmax(scores))
        confidence = float(scores[pred_idx])
        intent = self.LABEL_MAP[pred_idx]
        
        # Create score dict
        score_dict = {
            intent_class.value: float(scores[i])
            for i, intent_class in self.LABEL_MAP.items()
        }
        
        return ClassificationResult(
            intent=intent,
            confidence=confidence,
            scores=score_dict
        )
    
    def _classify_pytorch(self, text: str) -> ClassificationResult:
        """Classify using PyTorch"""
        # Tokenize
        inputs = self.tokenizer(
            text,
            padding=True,
            truncation=True,
            max_length=512,
            return_tensors="pt"
        )
        
        # Run inference
        with torch.no_grad():
            outputs = self.model(**inputs)
            logits = outputs.logits
        
        # Softmax
        probs = torch.softmax(logits, dim=-1)[0]
        scores = probs.numpy()
        
        # Get prediction
        pred_idx = int(np.argmax(scores))
        confidence = float(scores[pred_idx])
        intent = self.LABEL_MAP[pred_idx]
        
        # Create score dict
        score_dict = {
            intent_class.value: float(scores[i])
            for i, intent_class in self.LABEL_MAP.items()
        }
        
        return ClassificationResult(
            intent=intent,
            confidence=confidence,
            scores=score_dict
        )
    
    def _fallback_classify(self, text: str) -> ClassificationResult:
        """
        Advanced rule-based fallback classifier with feature analysis
        Distinguishes legitimate complex queries from malicious injections
        """
        # Import advanced classifier
        try:
            from cais.classification.advanced_classifier import AdvancedClassifier
            advanced = AdvancedClassifier()
            result, features = advanced.classify_with_features(text)
            
            # Generate detailed reasoning
            result.reasoning = advanced.explain_classification(features, result, text)
            
            # Log detailed analysis
            logger.debug(f"Advanced classification: {result.intent.value} "
                        f"(confidence: {result.confidence:.2f})")
            logger.debug(f"Features: technical_terms={features.technical_terms}, "
                        f"coherence={features.context_coherence:.2f}, "
                        f"malicious_signals={features.instruction_override_signals + features.role_manipulation_signals}")
            
            return result
        except Exception as e:
            logger.warning(f"Advanced classifier failed, using simple fallback: {e}")
            # Fall back to simple classification
            return self._simple_fallback_classify(text)
    
    def _simple_fallback_classify(self, text: str) -> ClassificationResult:
        """
        Simple rule-based fallback classifier (backup)
        Used when advanced classifier is not available
        """
        text_lower = text.lower()
        
        # Check for direct attacks (high priority)
        attack_keywords = [
            'ignore previous', 'disregard', 'forget everything',
            'you are now', 'dan mode', 'developer mode',
            'system prompt', 'jailbreak', 'bypass'
        ]
        
        attack_score = sum(1 for kw in attack_keywords if kw in text_lower)
        
        if attack_score >= 2:
            return ClassificationResult(
                intent=IntentClass.DIRECT_ATTACK,
                confidence=0.85,
                scores={
                    IntentClass.LEGITIMATE_QUERY.value: 0.05,
                    IntentClass.LEGITIMATE_CODE_ANALYSIS.value: 0.05,
                    IntentClass.DIRECT_ATTACK.value: 0.85,
                    IntentClass.INDIRECT_ATTACK.value: 0.05,
                }
            )
        
        # Check for code analysis
        analysis_keywords = [
            'analyze', 'review', 'check', 'inspect',
            'malware', 'exploit', 'vulnerability', 'cve',
            'security', 'code review'
        ]
        
        analysis_score = sum(1 for kw in analysis_keywords if kw in text_lower)
        
        if analysis_score >= 2:
            return ClassificationResult(
                intent=IntentClass.LEGITIMATE_CODE_ANALYSIS,
                confidence=0.75,
                scores={
                    IntentClass.LEGITIMATE_QUERY.value: 0.15,
                    IntentClass.LEGITIMATE_CODE_ANALYSIS.value: 0.75,
                    IntentClass.DIRECT_ATTACK.value: 0.05,
                    IntentClass.INDIRECT_ATTACK.value: 0.05,
                }
            )
        
        # Check for indirect attacks (code comments, etc.)
        if any(marker in text for marker in ['#', '//', '/*', '<!--']):
            if attack_score >= 1:
                return ClassificationResult(
                    intent=IntentClass.INDIRECT_ATTACK,
                    confidence=0.70,
                    scores={
                        IntentClass.LEGITIMATE_QUERY.value: 0.10,
                        IntentClass.LEGITIMATE_CODE_ANALYSIS.value: 0.15,
                        IntentClass.DIRECT_ATTACK.value: 0.05,
                        IntentClass.INDIRECT_ATTACK.value: 0.70,
                    }
                )
        
        # Default to legitimate query
        return ClassificationResult(
            intent=IntentClass.LEGITIMATE_QUERY,
            confidence=0.65,
            scores={
                IntentClass.LEGITIMATE_QUERY.value: 0.65,
                IntentClass.LEGITIMATE_CODE_ANALYSIS.value: 0.20,
                IntentClass.DIRECT_ATTACK.value: 0.10,
                IntentClass.INDIRECT_ATTACK.value: 0.05,
            }
        )
    
    @staticmethod
    def _softmax(x: np.ndarray) -> np.ndarray:
        """Compute softmax"""
        exp_x = np.exp(x - np.max(x))
        return exp_x / exp_x.sum()
