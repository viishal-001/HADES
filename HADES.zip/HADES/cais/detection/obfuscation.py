"""
Obfuscation Detection Module
Handles normalization and detection of adversarial text transformations including:
- Leetspeak (1337)
- Homoglyphs (Unicode confusion)
- Invisible characters / Zalgo text
- Spacing manipulation
"""
import re
import unicodedata
from typing import Tuple, List, Dict

class ObfuscationDetector:
    # Common Leetspeak mappings
    LEET_MAP = str.maketrans({
        '0': 'o', '1': 'i', '3': 'e', '4': 'a', '5': 's', '7': 't', 
        '@': 'a', '$': 's', '!': 'i', '+': 't', '(': 'c'
    })

    # Common Homoglyphs (Cyrillic to Latin, etc.)
    HOMOGLYPH_MAP = str.maketrans({
        'а': 'a', 'с': 'c', 'е': 'e', 'о': 'o', 'р': 'p', 'х': 'x', 'у': 'y', # Cyrillic
        'А': 'A', 'С': 'C', 'Е': 'E', 'О': 'O', 'Р': 'P', 'Х': 'X', # Cyrillic Caps
        'і': 'i', 'І': 'I', # Ukrainian
        'α': 'a', 'ε': 'e', 'ρ': 'p', # Greek
    })

    def detect_and_normalize(self, text: str) -> Tuple[str, List[str], float]:
        """
        Normalize text and return detected obfuscation signals.
        Returns: (normalized_text, detected_techniques, obfuscation_score)
        """
        original_text = text
        techniques = []
        obfuscation_score = 0.0

        # 1. Check for Invisible Characters
        # Zero-width spaces, joiners, variation selectors
        invisible_pattern = re.compile(r'[\u200b-\u200f\u202a-\u202e\ufeff]')
        if invisible_pattern.search(text):
            techniques.append('invisible_chars')
            obfuscation_score += 0.4
            text = invisible_pattern.sub('', text)

        # 2. Unicode Normalization (NFKC) usually fixes compatibility chars (ℍ -> H)
        normalized_unicode = unicodedata.normalize('NFKC', text)
        if normalized_unicode != text:
             # Just standard normalization, might not be an attack, but noteworthy if combined
             text = normalized_unicode

        # 3. Homoglyph Injection Check
        dehomoglyphed = text.translate(self.HOMOGLYPH_MAP)
        if dehomoglyphed != text:
            techniques.append('homoglyphs')
            obfuscation_score += 0.6
            text = dehomoglyphed

        # 4. Spaced Characters Attack (i g n o r e)
        # Pattern: Single char surrounded by spaces, repeated 3+ times
        spaced_pattern = re.compile(r'\b(?:[a-zA-Z]\s+){3,}[a-zA-Z]\b')
        if spaced_pattern.search(text):
            techniques.append('spacing_evasion')
            obfuscation_score += 0.5
            # Fix: Collapse spaces between single letters
            # Remove excessive spaces between characters
            text = re.sub(r'\b([a-zA-Z])\s+(?=[a-zA-Z])', r'\1', text)

        # 5. Leetspeak Check
        # Only check if strictly alphanumeric check fails but leet decode matches known bad words?
        # Simpler: Just decode generic leetspeak
        deleeted = text.translate(self.LEET_MAP)
        if deleeted != text:
            # We don't flag ALL numbers as leetspeak (e.g. 2024), 
            # but if it looks like words mix numbers, it's suspicious.
            # Heuristic: If deleeting reveals keywords we care about later, we count it.
            # For now, we assume it's a technique if significantly different
            diff_count = sum(1 for a, b in zip(text, deleeted) if a != b)
            if diff_count > 2: # Threshold to avoid false positives with regular numbers
                techniques.append('leetspeak')
                obfuscation_score += 0.3
                text = deleeted

        # 6. Base64 / Hex (Basic Check)
        # If input looks like big block of random chars, potential encoding
        if re.search(r'^[A-Za-z0-9+/]{20,}={0,2}$', original_text.strip()):
            # Potentially Base64 (simplified check)
            techniques.append('potential_encoding')
            obfuscation_score += 0.2
        
        return text, techniques, min(1.0, obfuscation_score)
