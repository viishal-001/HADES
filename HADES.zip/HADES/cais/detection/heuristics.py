"""
Fast-path detection using regex patterns and heuristics
Provides quick rejection of obvious attacks
"""
import re
from typing import List, Dict, Tuple
from loguru import logger


class HeuristicDetector:
    """Regex and pattern-based detection of known jailbreak attempts"""
    
    # Known jailbreak patterns (regex)
    JAILBREAK_PATTERNS = [
        # Direct instruction override
        (r'ignore\s+(all\s+)?(previous|above|prior)\s+instructions?', 'instruction_override'),
        (r'disregard\s+(all\s+)?(previous|above|prior)\s+(instructions?|prompts?)', 'instruction_override'),
        (r'forget\s+(everything|all)\s+(you\s+)?(were\s+told|learned)', 'instruction_override'),
        
        # Role/persona manipulation
        (r'you\s+are\s+now\s+(a|an)\s+\w+', 'persona_redefinition'),
        (r'(act|behave|pretend)\s+as\s+(if\s+)?(you\s+are|you\'re)\s+', 'persona_redefinition'),
        (r'from\s+now\s+on,?\s+you\s+(are|will\s+be)', 'persona_redefinition'),
        
        # DAN (Do Anything Now) variants
        (r'\bDAN\b.*mode', 'dan_jailbreak'),
        (r'do\s+anything\s+now', 'dan_jailbreak'),
        (r'developer\s+mode', 'developer_mode'),
        
        # System prompt leakage attempts
        (r'(show|reveal|display|print)\s+(your|the)\s+system\s+prompt', 'prompt_leakage'),
        (r'what\s+(are|were)\s+your\s+(initial|original)\s+instructions', 'prompt_leakage'),
        (r'repeat\s+(your|the)\s+(instructions|prompt)', 'prompt_leakage'),
        
        # Delimiter/boundary breaking
        (r'---\s*END\s+OF\s+(INSTRUCTIONS?|PROMPT)', 'delimiter_breaking'),
        (r'<\|.*?endof(text|prompt)\|>', 'delimiter_breaking'),
        (r'\[SYSTEM\]|\[/SYSTEM\]', 'delimiter_breaking'),
        
        # Encoding tricks
        (r'base64\s+decode\s+the\s+following', 'encoding_trick'),
        (r'rot13|caesar\s+cipher', 'encoding_trick'),
        
        # Hypothetical scenarios (common jailbreak technique)
        (r'imagine\s+you\s+are\s+not\s+bound\s+by', 'hypothetical_jailbreak'),
        (r'in\s+a\s+hypothetical\s+world\s+where', 'hypothetical_jailbreak'),
        
        # Emotional manipulation
        (r'my\s+(grandmother|grandma)\s+(used\s+to|would)', 'emotional_manipulation'),
        (r'(please|help),?\s+my\s+(life|job)\s+depends\s+on', 'emotional_manipulation'),

        # --- DLP: Data Loss Prevention patterns ---
        # AWS Keys
        (r'AKIA[0-9A-Z]{16}', 'dlp_aws_key_leak'),
        (r'(aws|access|secret).*?(key|token).*?[a-zA-Z0-9/+=]{20,}', 'dlp_secret_key_leak'),
        
        # Generic API Keys / Tokens
        (r'(api[_-]?key|token|secret)[ \t]*[:=][ \t]*[a-zA-Z0-9_\-]{16,}', 'dlp_generic_api_leak'),
        
        # PII: SSN (US)
        (r'\b\d{3}-\d{2}-\d{4}\b', 'dlp_pii_ssn'),
        # PII: Email (simple check in context of leakage)
        (r'email[:=]\s*[\w\.-]+@[\w\.-]+\.\w+', 'dlp_pii_email'),
        
        # XSS/Web Payloads
        (r'<script.*?>.*?</script>', 'xss_payload'),
        (r'javascript:\s*\w+', 'xss_payload'),
        (r'onload\s*=', 'xss_payload'),
        (r'onerror\s*=', 'xss_payload'),
        (r'alert\(.*?\)', 'xss_payload'),
    ]
    
    # Suspicious instruction keywords
    INSTRUCTION_KEYWORDS = [
        'ignore', 'disregard', 'forget', 'override', 'bypass',
        'jailbreak', 'unrestricted', 'unfiltered', 'uncensored',
        'sudo', 'admin', 'root', 'privilege'
    ]
    
    # Code comment injection patterns
    CODE_COMMENT_PATTERNS = [
        (r'//\s*IGNORE\s+PREVIOUS', 'code_comment_injection'),
        (r'#\s*NEW\s+INSTRUCTIONS?:', 'code_comment_injection'),
        (r'/\*\s*SYSTEM:', 'code_comment_injection'),
        (r'<!--\s*ADMIN\s+MODE', 'code_comment_injection'),
    ]
    
    def __init__(self):
        # Compile patterns for performance
        self.compiled_patterns = [
            (re.compile(pattern, re.IGNORECASE | re.MULTILINE), label)
            for pattern, label in self.JAILBREAK_PATTERNS
        ]
        
        self.code_comment_compiled = [
            (re.compile(pattern, re.IGNORECASE | re.MULTILINE), label)
            for pattern, label in self.CODE_COMMENT_PATTERNS
        ]
    
    def detect(self, text: str, check_code_comments: bool = True) -> Tuple[bool, float, List[str]]:
        """
        Detect jailbreak attempts using pattern matching
        
        Returns:
            (is_suspicious, confidence, matched_patterns)
        """
        matched_patterns = []
        
        # Check main jailbreak patterns
        for pattern, label in self.compiled_patterns:
            if pattern.search(text):
                matched_patterns.append(label)
                logger.warning(f"Jailbreak pattern detected: {label}")
        
        # Check code comment injections
        if check_code_comments:
            for pattern, label in self.code_comment_compiled:
                if pattern.search(text):
                    matched_patterns.append(label)
                    logger.warning(f"Code comment injection detected: {label}")
        
        # Check for suspicious keyword density
        keyword_count = sum(
            1 for keyword in self.INSTRUCTION_KEYWORDS
            if re.search(r'\b' + re.escape(keyword) + r'\b', text, re.IGNORECASE)
        )
        
        if keyword_count >= 3:
            matched_patterns.append('high_keyword_density')
        
        # Calculate confidence
        is_suspicious = len(matched_patterns) > 0
        confidence = min(0.95, len(matched_patterns) * 0.3) if is_suspicious else 0.0
        
        # Boost confidence for severe patterns
        severe_labels = [
            'xss_payload', 'instruction_override', 'code_comment_injection',
            'dlp_aws_key_leak', 'dlp_secret_key_leak', 'dlp_generic_api_leak',
            'dlp_pii_ssn', 'dlp_pii_email'
        ]
        if any(p in severe_labels for p in matched_patterns):
            confidence = max(confidence, 0.95)
        
        return is_suspicious, confidence, matched_patterns
    
    def check_instruction_override(self, text: str) -> bool:
        """Quick check for instruction override attempts"""
        override_pattern = re.compile(
            r'\b(ignore|disregard|forget|override)\s+(all\s+)?(previous|above|prior)',
            re.IGNORECASE
        )
        return bool(override_pattern.search(text))
    
    def check_persona_manipulation(self, text: str) -> bool:
        """Check for persona/role manipulation"""
        persona_pattern = re.compile(
            r'\b(you\s+are\s+now|act\s+as|pretend\s+to\s+be|from\s+now\s+on)',
            re.IGNORECASE
        )
        return bool(persona_pattern.search(text))
    
    def extract_suspicious_segments(self, text: str) -> List[Dict[str, str]]:
        """Extract text segments that match suspicious patterns"""
        segments = []
        
        for pattern, label in self.compiled_patterns:
            for match in pattern.finditer(text):
                segments.append({
                    'text': match.group(0),
                    'start': match.start(),
                    'end': match.end(),
                    'pattern': label
                })
        
        return segments


class ContextAnalyzer:
    """Analyzes context to distinguish legitimate security analysis from attacks"""
    
    # Legitimate security analysis indicators
    ANALYSIS_INDICATORS = [
        r'\b(analyze|review|check|inspect|examine)\b',
        r'\b(malware|exploit|vulnerability|CVE-\d+)\b',
        r'\b(security|threat|attack|payload)\s+(analysis|assessment|review)\b',
        r'\b(static|dynamic)\s+analysis\b',
        r'\bcode\s+review\b',
        r'\bpenetration\s+test(ing)?\b',
        r'\bred\s+team(ing)?\b',
    ]
    
    # Execution intent indicators (suspicious in security context)
    EXECUTION_INDICATORS = [
        r'\b(execute|run|launch|trigger|activate)\b',
        r'\b(do|perform|carry\s+out)\s+the\s+following\b',
        r'\bhelp\s+me\s+(create|build|make|generate)\b',
        r'\bshow\s+me\s+how\s+to\b',
    ]
    
    def __init__(self):
        self.analysis_patterns = [
            re.compile(pattern, re.IGNORECASE) for pattern in self.ANALYSIS_INDICATORS
        ]
        self.execution_patterns = [
            re.compile(pattern, re.IGNORECASE) for pattern in self.EXECUTION_INDICATORS
        ]
    
    def is_likely_analysis(self, text: str) -> Tuple[bool, float]:
        """
        Determine if text is likely legitimate security analysis
        
        Returns:
            (is_analysis, confidence)
        """
        analysis_matches = sum(1 for p in self.analysis_patterns if p.search(text))
        execution_matches = sum(1 for p in self.execution_patterns if p.search(text))
        
        # More analysis indicators and fewer execution indicators = likely legitimate
        if analysis_matches > 0 and execution_matches == 0:
            confidence = min(0.9, analysis_matches * 0.3)
            return True, confidence
        elif analysis_matches > execution_matches:
            confidence = min(0.7, (analysis_matches - execution_matches) * 0.2)
            return True, confidence
        else:
            return False, 0.0
    
    def extract_context_type(self, text: str) -> str:
        """Extract the type of security context"""
        if re.search(r'\b(code|source|script|function)\s+(review|analysis)\b', text, re.IGNORECASE):
            return 'code_review'
        elif re.search(r'\b(malware|virus|trojan)\s+(analysis|sample)\b', text, re.IGNORECASE):
            return 'malware_analysis'
        elif re.search(r'\b(log|alert|event)\s+(analysis|investigation)\b', text, re.IGNORECASE):
            return 'soc_analysis'
        elif re.search(r'\b(vulnerability|CVE|exploit)\b', text, re.IGNORECASE):
            return 'vulnerability_research'
        else:
            return 'general'
