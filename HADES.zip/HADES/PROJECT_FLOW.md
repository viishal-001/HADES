# 🌊 CAIS Project Flow & Architecture

This document outlines the high-level architecture and the detailed data flow of the CAIS (Context-Aware Intent Shield) project. It uses diagrams to visually explain how the system protects against adversarial prompt injections.

---

## 🏗️ System Architecture Overview

High-level component interaction showing how CAIS sits between the User and the LLM.

```mermaid
graph TD
    User[👤 User / Client App]
    
    subgraph CAIS_System [🛡️ CAIS Middleware]
        API[🚀 FastAPI Server]
        Pipeline[⚙️ Core Protection Pipeline]
        SessionDB[(Session Store)]
        
        API --> Pipeline
        Pipeline <--> SessionDB
    end
    
    LLM[🤖 Protected LLM Service]
    
    User -- "POST /protect (Input)" --> API
    Pipeline -- "Safe Input" --> LLM
    Pipeline -- "Blocked/Sanitized" --> User
```

---

## 🔄 Detailed Protection Flow

This flowchart illustrates exactly what happens to a user's input as it travels through the CAIS pipeline.

```mermaid
flowchart TD
    Start([User Input]) --> Step1[1. Input Validation\n(Length check, DLP)]
    
    Step1 --> Step2[2. Sanitization\n(Normalize, Decode)]
    
    Step2 --> Step3{3. Fast Detection\n(Regex/Heuristics)}
    
    Step3 -- "Attack Detected" --> Block[🚫 Block Request]
    Step3 -- "Suspicious" --> Step4[4. Intent Classification\n(ML/Advanced Logic)]
    Step3 -- "Safe" --> Step4
    
    Step4 --> Step5[5. Context Analysis\n(Is this code review?)]
    
    Step5 --> Step6[6. Session Risk Check\n(Multi-turn Tracking)]
    
    Step6 --> Step7{7. Mitigation Decision}
    
    Step7 -- "Direct Attack" --> Block
    Step7 -- "Legitimate Query" --> Allow([✅ Allow / Pass to LLM])
    Step7 -- "Indirect Attack" --> Sanitize([🧹 Sanitize & Contain])
    Step7 -- "High Risk" --> Challenge([❓ Reprompt User])

    Block --> Response([Return Result])
    Allow --> Response
    Sanitize --> Response
    Challenge --> Response
    
    style Start fill:#f9f,stroke:#333,stroke-width:2px
    style Block fill:#f00,stroke:#333,color:#fff
    style Allow fill:#0f0,stroke:#333,color:#000
    style Sanitize fill:#ff9,stroke:#333
```

---

## ⏱️ Request Sequence Diagram

A timeline view of a single request processing lifecycle.

```mermaid
sequenceDiagram
    participant U as User
    participant API as CAIS API
    participant Core as Core Pipeline
    participant Det as Detectors
    participant Sess as Session Tracker
    
    U->>API: POST /protect (input)
    activate API
    
    API->>Core: protect(input)
    activate Core
    
    Core->>Core: Normalize & Sanitize
    
    Core->>Det: detect_heuristics(input)
    Det-->>Core: specific_patterns_found (e.g. "Ignore Instructions")
    
    Core->>Core: classify_intent()
    
    Core->>Sess: update_risk(intent)
    Sess-->>Core: current_risk_score
    
    Core->>Core: determine_action(intent, risk)
    
    alt Action == BLOCK
        Core-->>API: Returning Blocked Result
    else Action == ALLOW
        Core-->>API: Returning Original Input
    else Action == SANITIZE
        Core-->>Core: Apply XML Spotlighting
        Core-->>API: Returning Sanitized Input
    end
    
    deactivate Core
    
    API-->>U: JSON Response (Action, Reason, etc.)
    deactivate API
```

---

## 📂 Project Structure Map

How the files map to the architecture above:

*   **`cais/api/server.py`**: The entry point (API) in the first diagram.
*   **`cais/core.py`**: The 'Core Pipeline' orchestration logic.
*   **`cais/detection/`**: Contains the `heuristics.py` (Fast Detection) and `obfuscation.py`.
*   **`cais/classification/`**: Contains `classifier.py` and `advanced_classifier.py` (Intent Classification).
*   **`cais/session/`**: Contains `tracker.py` (Session Risk Check).
*   **`cais/mitigation/`**: Contains `actions.py` (Mitigation Decision & Application).

## 🧠 Key Decision Logic

1.  **Fast Path**: If a regex pattern matches a known "jailbreak" (e.g., "DAN mode"), we catch it early in `heuristics.py`.
2.  **Context Aware**: We differentiate between *doing* an attack and *analyzing* an attack.
    *   *Input*: "Write a SQL injection" -> **Blocked** (Action)
    *   *Input*: "Explain how this SQL injection works" -> **Allowed** (Analysis)
3.  **Session Risk**: One slightly suspicious question might be fine, but 5 in a row will raise the Session Risk Score to 'High' and eventually trigger a block.
