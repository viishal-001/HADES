# CAIS Project Index

## 📚 Quick Navigation

### Getting Started
1. **[README.md](README.md)** - Project overview and features
2. **[GETTING_STARTED.md](GETTING_STARTED.md)** - Installation and quick start guide
3. **[PROJECT_SUMMARY.md](PROJECT_SUMMARY.md)** - Complete feature summary
4. **[quickstart.py](quickstart.py)** - Interactive demo script

### Documentation
- **[ARCHITECTURE.md](ARCHITECTURE.md)** - System architecture and data flow
- **[IMPLEMENTATION_PLAN.md](IMPLEMENTATION_PLAN.md)** - Development roadmap
- **[LICENSE](LICENSE)** - MIT License

### Configuration
- **[requirements.txt](requirements.txt)** - Python dependencies
- **[config.example.yaml](config.example.yaml)** - Configuration template
- **[.env.example](.env.example)** - Environment variables template
- **[.gitignore](.gitignore)** - Git ignore patterns

### Deployment
- **[Dockerfile](Dockerfile)** - Container image definition
- **[docker-compose.yml](docker-compose.yml)** - Container orchestration

## 🗂️ Source Code Structure

### Core Package (`cais/`)

#### Main Files
- **`__init__.py`** - Package exports and version
- **`models.py`** - Pydantic data models (ProtectionResult, IntentClass, etc.)
- **`core.py`** - Main CAISMiddleware orchestrator

#### Modules

**Sanitization (`cais/sanitization/`)**
- `normalizer.py` - Unicode normalization, encoding detection, decoding
- `__init__.py` - Module exports

**Detection (`cais/detection/`)**
- `heuristics.py` - Regex-based pattern matching, context analysis
- `vector_search.py` - Semantic similarity using embeddings + FAISS
- `__init__.py` - Module exports

**Classification (`cais/classification/`)**
- `classifier.py` - Intent classification (ONNX/PyTorch + fallback)
- `__init__.py` - Module exports

**Session (`cais/session/`)**
- `tracker.py` - Multi-turn risk tracking and session management
- `__init__.py` - Module exports

**Mitigation (`cais/mitigation/`)**
- `actions.py` - Mitigation strategies (block/sanitize/allow/challenge)
- `__init__.py` - Module exports

**API (`cais/api/`)**
- `server.py` - FastAPI REST service
- `__init__.py` - Module exports

## 🧪 Tests (`tests/`)

- **`__init__.py`** - Test package
- **`test_sanitization.py`** - Sanitization module tests
- **`test_detection.py`** - Detection module tests
- **`test_integration.py`** - Full pipeline integration tests
- **`run_tests.py`** - Test runner script

## 📖 Examples (`examples/`)

- **`code_reviewer_demo.py`** - AI code reviewer integration example
- **`api_client_demo.py`** - REST API client example

## 🎯 Key Files by Use Case

### I want to understand the project
1. Start with [README.md](README.md)
2. Read [PROJECT_SUMMARY.md](PROJECT_SUMMARY.md)
3. Review [ARCHITECTURE.md](ARCHITECTURE.md)

### I want to run CAIS
1. Follow [GETTING_STARTED.md](GETTING_STARTED.md)
2. Run `python quickstart.py`
3. Try `python examples/code_reviewer_demo.py`

### I want to integrate CAIS
1. See `examples/code_reviewer_demo.py` for library usage
2. See `examples/api_client_demo.py` for API usage
3. Check `cais/core.py` for the main interface

### I want to customize CAIS
1. Review [ARCHITECTURE.md](ARCHITECTURE.md) for extension points
2. Add patterns in `cais/detection/heuristics.py`
3. Modify mitigation in `cais/mitigation/actions.py`
4. Adjust config in `cais/models.py`

### I want to deploy CAIS
1. Use [Dockerfile](Dockerfile) for containerization
2. Use [docker-compose.yml](docker-compose.yml) for orchestration
3. Configure via [config.example.yaml](config.example.yaml)

### I want to test CAIS
1. Run `pytest tests/ -v`
2. Check `tests/test_integration.py` for examples
3. Use `run_tests.py` for full suite

## 📊 File Statistics

### Lines of Code (Approximate)
```
Core Implementation:
  cais/core.py                 ~250 lines
  cais/models.py               ~150 lines
  cais/sanitization/           ~200 lines
  cais/detection/              ~400 lines
  cais/classification/         ~250 lines
  cais/session/                ~200 lines
  cais/mitigation/             ~250 lines
  cais/api/                    ~300 lines
  ─────────────────────────────────────
  Total Core:                  ~2000 lines

Tests:
  tests/                       ~500 lines

Examples:
  examples/                    ~300 lines

Documentation:
  *.md files                   ~2000 lines
```

### Module Dependencies
```
cais/core.py
  ├── cais/models.py
  ├── cais/sanitization/normalizer.py
  ├── cais/detection/heuristics.py
  ├── cais/detection/vector_search.py
  ├── cais/classification/classifier.py
  ├── cais/session/tracker.py
  └── cais/mitigation/actions.py

cais/api/server.py
  └── cais/core.py
```

## 🔍 Finding Specific Features

### Attack Detection
- **Regex patterns**: `cais/detection/heuristics.py` → `JAILBREAK_PATTERNS`
- **Vector search**: `cais/detection/vector_search.py` → `VectorDetector`
- **Context analysis**: `cais/detection/heuristics.py` → `ContextAnalyzer`

### Intent Classification
- **Main classifier**: `cais/classification/classifier.py` → `IntentClassifier`
- **Intent types**: `cais/models.py` → `IntentClass`
- **Fallback logic**: `cais/classification/classifier.py` → `_fallback_classify`

### Session Tracking
- **Risk scoring**: `cais/session/tracker.py` → `SessionTracker.update`
- **Pattern detection**: `cais/session/tracker.py` → `_detect_attack_patterns`
- **Session locking**: `cais/session/tracker.py` → `_lock_session`

### Mitigation
- **Action decision**: `cais/mitigation/actions.py` → `MitigationEngine.determine_action`
- **XML spotlighting**: `cais/mitigation/actions.py` → `_apply_spotlighting`
- **Containment**: `cais/mitigation/actions.py` → `_add_containment`

### API Endpoints
- **Protection**: `cais/api/server.py` → `@app.post("/protect")`
- **Validation**: `cais/api/server.py` → `@app.post("/validate-response")`
- **Session info**: `cais/api/server.py` → `@app.get("/session/{session_id}")`

## 🎓 Learning Path

### Beginner
1. Run `quickstart.py`
2. Read `README.md`
3. Try `examples/code_reviewer_demo.py`

### Intermediate
1. Read `ARCHITECTURE.md`
2. Review `cais/core.py`
3. Explore `tests/test_integration.py`

### Advanced
1. Study `cais/detection/` for detection algorithms
2. Review `cais/classification/` for ML integration
3. Examine `cais/session/` for stateful tracking
4. Customize `cais/mitigation/` for your use case

## 🚀 Common Tasks

### Add a new jailbreak pattern
Edit: `cais/detection/heuristics.py`
```python
JAILBREAK_PATTERNS = [
    # Add your pattern here
    (r'your_regex_pattern', 'pattern_label'),
]
```

### Adjust risk thresholds
Edit: `cais/models.py`
```python
class Config(BaseModel):
    session_risk_threshold: float = 70.0  # Adjust this
```

### Change mitigation behavior
Edit: `cais/mitigation/actions.py`
```python
def determine_action(self, intent, confidence, risk_level, is_session_locked):
    # Modify logic here
```

### Add custom endpoint
Edit: `cais/api/server.py`
```python
@app.post("/your-endpoint")
async def your_endpoint():
    # Your code here
```

## 📞 Support Resources

- **API Docs**: Run server and visit `http://localhost:8000/docs`
- **Test Examples**: See `tests/` directory
- **Integration Examples**: See `examples/` directory
- **Architecture**: See `ARCHITECTURE.md`
- **Troubleshooting**: See `GETTING_STARTED.md` → Troubleshooting section

## 🏆 Project Highlights

✅ **2000+ lines** of production-quality Python code  
✅ **Multi-layer defense** architecture  
✅ **Context-aware** intent classification  
✅ **Stateful** session tracking  
✅ **REST API** with OpenAPI docs  
✅ **Docker** deployment ready  
✅ **Comprehensive** test suite  
✅ **Extensive** documentation  

---

**Navigate efficiently. Build confidently. Deploy securely.**
