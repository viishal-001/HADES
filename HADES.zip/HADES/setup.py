from setuptools import setup, find_packages

setup(
    name="cais",
    version="0.1.0",
    description="Context-Aware Intent Shield - A low-latency defense middleware for LLM-powered security tools",
    author="CAIS Team",
    packages=find_packages(),
    python_requires=">=3.9",
    install_requires=[
        "fastapi>=0.109.0",
        "uvicorn[standard]>=0.27.0",
        "pydantic>=2.5.0",
        "pydantic-settings>=2.1.0",
        "transformers>=4.36.0",
        "sentence-transformers>=2.3.1",
        "torch>=2.1.2",
        "numpy>=1.24.3",
        "pandas>=2.1.4",
        "scikit-learn>=1.3.2",
        "python-multipart>=0.0.6",
        "python-dotenv>=1.0.0",
        "pyyaml>=6.0.1",
        "loguru>=0.7.2",
        "prometheus-client>=0.19.0",
        "requests>=2.32.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.4.3",
            "pytest-asyncio>=0.21.1",
            "pytest-cov>=4.1.0",
            "httpx>=0.26.0",
            "black>=23.12.1",
            "flake8>=7.0.0",
            "mypy>=1.8.0",
        ]
    },
)
