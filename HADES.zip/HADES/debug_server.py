from cais.api.server import lifespan, app
import asyncio

async def test_startup():
    print("Testing startup...")
    async with lifespan(app):
        print("Startup successful!")
        from cais.api.server import llm_provider
        print(f"LLM Provider: {llm_provider}")

if __name__ == "__main__":
    asyncio.run(test_startup())
