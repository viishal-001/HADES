# Getting Started with CAIS

This guide will help you get CAIS up and running quickly.

## Prerequisites

- Python 3.9 or higher
- pip
- (Optional) Docker for containerized deployment

## Installation

### Option 1: Local Installation

1. **Clone or navigate to the project directory:**
   ```bash
   cd hack
   ```

2. **Create a virtual environment (recommended):**
   ```bash
   python -m venv venv
   
   # Windows
   venv\Scripts\activate
   
   # Linux/Mac
   source venv/bin/activate
   ```

3. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

### Option 2: Docker Installation

1. **Build the Docker image:**
   ```bash
   docker-compose build
   ```

2. **Start the service:**
   ```bash
   docker-compose up -d
   ```

## Quick Start

### 1. Run the Quick Start Demo

The fastest way to see CAIS in action:

```bash
python quickstart.py
```

This will demonstrate:
- ✅ Blocking direct attacks
- ✅ Allowing legitimate queries
- ✅ Sanitizing indirect injections
- ✅ Detecting encoded attacks
- ✅ Session risk tracking

### 2. Start the API Server

```bash
python -m cais.api.server
```

The API will be available at `http://localhost:8000`

- API Documentation: `http://localhost:8000/docs`
- Health Check: `http://localhost:8000/health`

### 3. Try the Examples

#### Code Reviewer Demo
```bash
python examples/code_reviewer_demo.py
```

Shows how to integrate CAIS into an AI code review tool.

#### API Client Demo
```bash
# In one terminal, start the server
python -m cais.api.server

# In another terminal, run the client
python examples/api_client_demo.py
```

## Basic Usage

### Python Library

```python
from cais import CAISMiddleware

# Initialize
cais = CAISMiddleware()

# Protect user input
result = cais.protect(
    input_text="How do I implement authentication?",
    session_id="user123"
)

# Check the result
if result.action == "allow":
    # Safe to send to LLM
    llm_response = your_llm.generate(result.sanitized_input)
else:
    # Attack detected
    print(f"Blocked: {result.reason}")
```

### REST API

```bash
# Protect input
curl -X POST http://localhost:8000/protect \
  -H "Content-Type: application/json" \
  -d '{
    "session_id": "user123",
    "input": "How do I implement authentication?",
    "context": "code_review"
  }'

# Check session
curl http://localhost:8000/session/user123

# Reset session
curl -X POST http://localhost:8000/session/user123/reset
```

## Running Tests

```bash
# Run all tests
pytest tests/ -v

# Run specific test file
pytest tests/test_integration.py -v

# Run with coverage
pytest tests/ --cov=cais --cov-report=html
```

## Configuration

### Using Config Object

```python
from cais import CAISMiddleware
from cais.models import Config

config = Config(
    vector_detection_enabled=True,
    auto_block_direct_attacks=True,
    session_risk_threshold=70.0
)

cais = CAISMiddleware(config)
```

### Using Environment Variables

Create a `.env` file:

```bash
cp .env.example .env
# Edit .env with your settings
```

## Common Use Cases

### 1. AI Code Reviewer

```python
from cais import CAISMiddleware

cais = CAISMiddleware()

def review_code(code, user_query, session_id):
    # Protect the query
    result = cais.protect(user_query, session_id, context="code_review")
    
    if result.action == "block":
        return "Query rejected"
    
    # Safe to analyze
    return llm.analyze(result.sanitized_input, code)
```

### 2. SOC Assistant

```python
def analyze_alert(alert_data, analyst_query, session_id):
    result = cais.protect(analyst_query, session_id, context="soc_analysis")
    
    if result.action == "sanitize":
        # Indirect injection detected
        alert_data = result.sanitized_input
    
    return llm.triage(result.sanitized_input, alert_data)
```

### 3. Security Chatbot

```python
def chat(user_message, session_id):
    result = cais.protect(user_message, session_id)
    
    if result.action == "block":
        return "I cannot process that request."
    
    # Validate response too
    llm_response = llm.generate(result.sanitized_input)
    is_safe, _ = cais.validate_response(llm_response)
    
    if not is_safe:
        llm_response = cais.sanitize_response(llm_response)
    
    return llm_response
```

## Performance Optimization

### 1. Use ONNX Models

ONNX models are faster for CPU inference:

```python
config = Config(use_onnx=True)
cais = CAISMiddleware(config)
```

### 2. Disable Vector Detection (if needed)

For ultra-low latency:

```python
config = Config(vector_detection_enabled=False)
cais = CAISMiddleware(config)
```

### 3. Adjust Input Length Limits

```python
config = Config(max_input_length=4096)  # Smaller = faster
cais = CAISMiddleware(config)
```

## Monitoring

### Check Service Health

```bash
curl http://localhost:8000/health
```

### View Logs

```bash
# Local installation
tail -f logs/cais_*.log

# Docker
docker-compose logs -f cais
```

### Session Statistics

```python
session_info = cais.get_session_info("user123")
print(f"Risk Score: {session_info['risk_score']}")
print(f"Turn Count: {session_info['turn_count']}")
```

## Troubleshooting

### Issue: "Model not found"

The MVP uses a fallback classifier when models aren't available. To train a custom model:

```bash
# TODO: Add model training script
python scripts/train_classifier.py
```

### Issue: "Vector detection disabled"

Install sentence-transformers:

```bash
pip install sentence-transformers faiss-cpu
```

### Issue: High latency

1. Use ONNX models
2. Disable vector detection
3. Reduce max_input_length
4. Enable caching

### Issue: Too many false positives

Adjust confidence threshold:

```python
config = Config(confidence_threshold=0.8)  # Higher = stricter
```

## Next Steps

1. **Integrate with your LLM application**
2. **Customize detection patterns** in `cais/detection/heuristics.py`
3. **Train a custom classifier** on your specific use case
4. **Set up monitoring** and alerting
5. **Review logs** for attack patterns

## Resources

- API Documentation: `http://localhost:8000/docs`
- Implementation Plan: `IMPLEMENTATION_PLAN.md`
- Examples: `examples/`
- Tests: `tests/`

## Support

For issues or questions:
1. Check the logs
2. Review the test cases
3. Consult the API documentation
4. Examine the example implementations
