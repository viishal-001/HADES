# CAIS MVP Implementation Plan

## Project Overview
Context-Aware Intent Shield (CAIS) - A low-latency, intent-aware defense layer protecting LLM-powered security tools from prompt injection attacks.

## Architecture Components

### 1. Core Modules
```
cais/
├── sanitization/          # Sanitization & Normalization Engine (SNE)
│   ├── normalizer.py     # Unicode normalization, decoding
│   └── cleaner.py        # Character filtering
├── detection/            # Fast-Path Detection
│   ├── heuristics.py     # Regex-based detection
│   └── vector_search.py  # Embedding similarity search
├── classification/       # Intent Classification
│   ├── classifier.py     # Main classifier interface
│   └── model.py          # Model loading & inference
├── session/              # Stateful Session Tracking
│   └── tracker.py        # Risk scoring & session management
├── mitigation/           # Mitigation Layer
│   └── actions.py        # Block/Sanitize/Allow logic
└── api/                  # FastAPI Service
    └── server.py         # REST API endpoints
```

### 2. Data & Models
```
data/
├── jailbreak_patterns.json    # Known attack patterns
├── attack_vectors.json        # Vector embeddings of attacks
└── legitimate_samples.json    # Legitimate security queries
models/
└── intent_classifier/         # Fine-tuned BERT model
    ├── model.onnx
    ├── tokenizer/
    └── config.json
```

### 3. Testing & Evaluation
```
tests/
├── test_sanitization.py
├── test_detection.py
├── test_classification.py
└── test_integration.py
evaluation/
├── benchmark.py              # ASR, FPR, latency testing
└── test_cases.json          # Evaluation dataset
```

## Implementation Phases

### Phase 1: Foundation (Core Infrastructure)
- [x] Project structure
- [ ] Sanitization & Normalization Engine
- [ ] Configuration management
- [ ] Logging framework

### Phase 2: Detection Layer
- [ ] Regex-based heuristics
- [ ] Vector similarity search (FAISS)
- [ ] Attack pattern database

### Phase 3: Intent Classification
- [ ] Dataset preparation
- [ ] Model fine-tuning (BERT/ModernBERT)
- [ ] ONNX conversion & optimization
- [ ] Inference engine

### Phase 4: Session & Mitigation
- [ ] Session tracking
- [ ] Risk scoring algorithm
- [ ] Mitigation actions (block/sanitize/allow)
- [ ] XML spotlighting for sanitization

### Phase 5: API & Integration
- [ ] FastAPI middleware service
- [ ] Integration demo (AI code reviewer)
- [ ] Docker containerization

### Phase 6: Evaluation & Documentation
- [ ] Benchmark suite
- [ ] Performance evaluation
- [ ] Documentation & deployment guide

## Technical Decisions

### Intent Classification Categories
1. **Legitimate_Query**: Normal security questions
2. **Legitimate_Code_Analysis**: Malware/exploit analysis requests
3. **Direct_Attack**: Direct jailbreak attempts
4. **Indirect_Attack**: Embedded injection in content

### Risk Scoring Algorithm
- Base score per intent class
- Accumulation across session turns
- Threshold-based mitigation triggers

### Mitigation Strategies
- **Direct_Attack**: Block immediately
- **Indirect_Attack**: Sanitize using XML spotlighting
- **Legitimate_Code_Analysis**: Allow with containment markers
- **Legitimate_Query**: Pass through

## Success Metrics (MVP Targets)
- Attack Success Rate (ASR): < 1%
- False Positive Rate (FPR): < 5%
- P99 Latency: < 50ms
- Instruction Retention: > 95%

## Dependencies
```
fastapi==0.109.0
uvicorn==0.27.0
transformers==4.36.0
onnxruntime==1.16.3
faiss-cpu==1.7.4
sentence-transformers==2.3.1
pydantic==2.5.0
numpy==1.24.3
scikit-learn==1.3.2
```

## Deployment Model
- CPU-only inference
- Docker container
- REST API on port 8000
- Stateless with optional Redis for session tracking
